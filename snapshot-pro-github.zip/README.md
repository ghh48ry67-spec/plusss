# SnapShot Pro — Windows Floating Screenshot Tool

A small Windows desktop screenshot utility with a movable floating button.

## Features
- Floating always-on-top capture button.
- Closing the main window hides it while the background app remains running.
- Left-click the floating button to capture the full desktop.
- Right-click for Open App, Save Folder, and Exit.
- Saves PNG files to `Pictures/SnapShot Pro`.
- Built by GitHub Actions as a Windows `.exe`.

## Build the EXE using GitHub
1. Create a GitHub repository named `snapshot-pro`.
2. Upload all files and folders from this project. Keep `.github/workflows/build-windows.yml` in its exact folder.
3. Open the repository's **Actions** tab.
4. Select **Build SnapShot Pro for Windows** and click **Run workflow**, or push a commit to `main`.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run. Under **Artifacts**, download `SnapShotPro-Windows-EXE`.
7. Extract the downloaded ZIP and run `SnapShotPro.exe`.

## Important
- This is a Windows desktop program, not a GitHub Pages website.
- The floating button remains only while SnapShot Pro is running. Choose **Exit SnapShot Pro** from its right-click menu to close it completely.
- The app captures the full desktop, including all connected monitors.
- Windows may show a security warning for a newly built, unsigned EXE. Only run the EXE you built from your own repository.
- The workflow uses a Windows Server 2019 build runner and Python 3.8.10. Compatibility with older Windows versions should be tested on the target laptop.
