import os
import tkinter as tk
from tkinter import messagebox
from pathlib import Path
from datetime import datetime

import mss
import mss.tools

APP_NAME = "SnapShot Pro"
SAVE_DIR = Path.home() / "Pictures" / APP_NAME
BUBBLE_SIZE = 58


class SnapShotPro:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("520x350")
        self.root.minsize(420, 290)
        self.root.configure(bg="#101729")
        self.root.protocol("WM_DELETE_WINDOW", self.hide_main)

        self.status = tk.StringVar(value="Ready. Floating camera is active.")
        self.build_main()
        self.build_bubble()
        self.build_menu()
        SAVE_DIR.mkdir(parents=True, exist_ok=True)
        self.bubble.deiconify()

    def build_main(self):
        tk.Label(self.root, text="📸  SnapShot Pro",
                 font=("Segoe UI", 21, "bold"), fg="#f3f5ff",
                 bg="#101729").pack(anchor="w", padx=22, pady=(20, 4))
        tk.Label(self.root, text="Windows Floating Screenshot Tool",
                 font=("Segoe UI", 10), fg="#9aa8c5",
                 bg="#101729").pack(anchor="w", padx=24)

        panel = tk.Frame(self.root, bg="#19243b",
                         highlightbackground="#30405f", highlightthickness=1)
        panel.pack(fill="both", expand=True, padx=22, pady=18)

        tk.Label(panel, text="Your screenshot assistant is running",
                 font=("Segoe UI", 13, "bold"), fg="#f3f5ff",
                 bg="#19243b").pack(anchor="w", padx=18, pady=(18, 8))
        tk.Label(panel,
                 text="Click the floating camera button to capture the entire desktop.\n"
                      "Closing this window keeps the floating button running.",
                 font=("Segoe UI", 10), fg="#b3bfd8",
                 bg="#19243b", justify="left").pack(anchor="w", padx=18)

        tk.Label(panel, textvariable=self.status, font=("Segoe UI", 9),
                 fg="#79dfb2", bg="#19243b", wraplength=430,
                 justify="left").pack(anchor="w", padx=18, pady=18)

        row = tk.Frame(panel, bg="#19243b")
        row.pack(anchor="w", padx=18, pady=(0, 18))
        tk.Button(row, text="Capture screenshot", command=self.capture,
                  bg="#7968f5", fg="white", relief="flat",
                  padx=12, pady=9).pack(side="left")
        tk.Button(row, text="Open save folder", command=self.open_folder,
                  bg="#293753", fg="white", relief="flat",
                  padx=12, pady=9).pack(side="left", padx=9)

        tk.Label(self.root,
                 text="Right-click the floating icon for more options.",
                 font=("Segoe UI", 8), fg="#7786a4",
                 bg="#101729").pack(anchor="w", padx=24, pady=(0, 12))

    def build_bubble(self):
        self.bubble = tk.Toplevel(self.root)
        self.bubble.overrideredirect(True)
        self.bubble.attributes("-topmost", True)
        self.bubble.configure(bg="#8876ff")
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.bubble.geometry(f"{BUBBLE_SIZE}x{BUBBLE_SIZE}+{sw-BUBBLE_SIZE-30}+{sh//2}")

        self.canvas = tk.Canvas(self.bubble, width=BUBBLE_SIZE,
                                height=BUBBLE_SIZE, bg="#8876ff",
                                highlightthickness=0, cursor="hand2")
        self.canvas.pack()
        self.canvas.create_oval(3, 3, 55, 55, fill="#8876ff",
                                 outline="#c3baff", width=2)
        self.canvas.create_text(29, 29, text="CAM",
                                fill="white", font=("Segoe UI", 9, "bold"))
        self.drag = None
        self.moved = False
        self.canvas.bind("<ButtonPress-1>", self.drag_start)
        self.canvas.bind("<B1-Motion>", self.drag_motion)
        self.canvas.bind("<ButtonRelease-1>", self.drag_end)
        self.bubble.bind("<Button-3>", self.popup)

    def build_menu(self):
        self.menu = tk.Menu(self.bubble, tearoff=0)
        self.menu.add_command(label="Take screenshot", command=self.capture)
        self.menu.add_command(label="Open SnapShot Pro", command=self.show_main)
        self.menu.add_command(label="Open screenshots folder", command=self.open_folder)
        self.menu.add_separator()
        self.menu.add_command(label="Exit SnapShot Pro", command=self.exit_app)

    def drag_start(self, event):
        self.drag = (event.x_root, event.y_root,
                     self.bubble.winfo_x(), self.bubble.winfo_y())
        self.moved = False

    def drag_motion(self, event):
        if not self.drag:
            return
        x0, y0, wx, wy = self.drag
        dx, dy = event.x_root - x0, event.y_root - y0
        if abs(dx) > 4 or abs(dy) > 4:
            self.moved = True
        self.bubble.geometry(f"+{wx+dx}+{wy+dy}")

    def drag_end(self, event):
        if not self.moved:
            self.capture()
        self.drag = None

    def popup(self, event):
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def hide_main(self):
        self.root.withdraw()
        self.bubble.deiconify()
        self.bubble.lift()
        self.status.set("Running in background. Floating camera is active.")

    def show_main(self):
        self.root.deiconify()
        self.root.lift()

    def open_folder(self):
        SAVE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(SAVE_DIR))
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def capture(self):
        try:
            SAVE_DIR.mkdir(parents=True, exist_ok=True)
            name = "Screenshot_" + datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + ".png"
            path = SAVE_DIR / name
            with mss.mss() as sct:
                monitor = sct.monitors[0]
                shot = sct.grab(monitor)
                mss.tools.to_png(shot.rgb, shot.size, output=str(path))
            self.status.set("Screenshot saved: " + str(path))
            self.root.bell()
        except Exception as exc:
            messagebox.showerror(APP_NAME, "Screenshot failed:\n" + str(exc))

    def exit_app(self):
        if messagebox.askyesno(APP_NAME, "Exit SnapShot Pro completely?"):
            self.bubble.destroy()
            self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    SnapShotPro(root)
    root.mainloop()
